# Public integration patterns

These examples show public contracts only. Adapt names, ownership, UI, and error presentation to the consumer app.

## Complete initialization

```swift
import AIBuds
import AIBudsAllInOne

let initialized = AIBudsAllInOneSDK.initialize(appSDKDelegate)
guard initialized else {
    // Present a stable configuration error and do not start scanning.
    return
}
```

Use the overload with `SDKConfiguration` when the app needs non-default public settings.

## Modular connection initialization

```swift
import AIBuds
import ABMate

let configuration = SDKConfiguration.default()
configuration.scanTimeoutInSeconds = 10
configuration.shouldAutoReconnectWhenAppLaunch = false

let initialized = AIBudsSDK.initialize(
    [ABMateSDK.shared],
    configuration: configuration,
    delegate: appSDKDelegate
)

guard initialized else {
    // Check dependency selection and required Info.plist descriptions.
    return
}
```

Keep `appSDKDelegate` strongly owned for as long as callbacks are needed. Initialize once during the app's startup path.

If the app uses a different public `BleConnectSDK` provider, pass that provider instead of `ABMateSDK.shared`.

## Optional on-device voice-assistant authentication

For modular installation, register the bundled public plugin during startup before device authentication can begin:

```swift
import AIBuds
import ABMate
import AIBudsVoiceAssistant

AIBudsSDK.setOnDeviceVoiceAssistantPlugin(VoiceAssistantSDK.bridgePlugin)

let initialized = AIBudsSDK.initialize(
    [ABMateSDK.shared],
    delegate: appSDKDelegate
)
```

Observe the public result without making assumptions about the authentication mechanism:

```swift
func device(
    _ device: DeviceConvertible,
    didReceiveOnDeviceVoiceAssistantAuthResult isSuccess: Bool,
    error: NSError?
) {
    DispatchQueue.main.async {
        if isSuccess {
            // Mark the public capability as available in the app.
        } else {
            let message = error?.localizedDescription
                ?? "On-device voice-assistant authentication failed."
            // Present the failure using the app's existing error UI.
        }
    }
}
```

This callback is the supported observation point. Do not log bridge data, credentials, or device identifiers.

## Discovery and connection

```swift
AIBudsSDK.startScanning(nil, deviceFoundHandler: { found, isExisting in
    // Update or insert the discovered device in the app's existing list.
    // Do not connect repeatedly for RSSI updates when isExisting is true.
}, completion: {
    DispatchQueue.main.async {
        // Scanning stopped. Present a stable empty state when no device was found.
    }
})
```

When the user selects a discovered device:

```swift
guard let device = AIBudsSDK.makeStorableDeviceFromDiscovered(foundDevice) else {
    // The discovery result could not become a supported storable device.
    return
}

device.delegate = appDeviceDelegate
device.save()
device.connect(ConnectParams())
```

Use callbacks as the source of truth:

```swift
func deviceDidReady(_ device: DeviceConvertible) {
    DispatchQueue.main.async {
        // The device is connected and ready for supported public feature APIs.
    }
}

func device(_ device: DeviceConvertible?, didDisconnectWithError error: NSError?) {
    DispatchQueue.main.async {
        // Update app state and offer recovery appropriate to the app.
    }
}
```

Do not treat discovery, a call to `connect`, or the lower-level connected callback as readiness. Stop scanning when the app's UX no longer needs it.

## App-owned AI boundary

An app-owned AI service is not initialized through `AIBudsAISDK` unless the developer is deliberately implementing an officially documented AIBuds AI provider contract. Follow the public [Bring Your Own AI Service](https://docs-aibuds.github.io/docs/advanced-topics/bring-your-own-ai) workflow.

After the app authenticates its own service, report only the current Boolean authorization result to the device:

```swift
func selfAIAuthenticationDidFinish(isAuthenticated: Bool) {
    guard let serviceAuthAPI = device as? DeviceServiceAuthAPI else {
        // The connected device does not expose this public capability.
        return
    }

    serviceAuthAPI.reportSelfAiServiceAuthResult(isAuthenticated) {
        reportSucceeded,
        error in

        DispatchQueue.main.async {
            guard reportSucceeded else {
                let message = error?.localizedDescription
                    ?? "Failed to report AI service authorization."
                // Present the delivery failure through the app's existing UI.
                return
            }

            // The Boolean result was delivered to the device.
            // This completion does not authenticate the app's AI service.
        }
    }
}
```

Report `true` only when the app-owned service is ready. Report `false` after an authentication failure or whenever the service is no longer available. Never pass credentials, tokens, or API keys through this API. See [Report Self-AI Authorization](https://docs-aibuds.github.io/docs/core/auth/notify-ai-auth-result) for the complete public contract.

After a successful report, keep the normal device-facing flow for the selected feature. The device continues to select the documented SCO or Opus audio path; app-owned AI does not create a parallel connection or session lifecycle. Read and cite the specific official page for AI Chat, AI Audio Recording, Streaming ASR, Simultaneous Interpretation, or the requested feature before producing its event/audio code.

## Capability checks

Device features are exposed by public capability protocols. Check conformance before use:

```swift
guard let voiceDevice = device as? OnDeviceVoiceAssistantAPI else {
    // Hide or disable unsupported UI.
    return
}
```

Never force-cast a feature protocol and never assume every product or firmware supports the same capability.

## Objective-C mapping

Use the generated Objective-C names exposed by public headers. The modular startup shape is:

```objective-c
@import AIBuds;
@import ABMate;

AIBudsSDKConfiguration *configuration = [AIBudsSDKConfiguration defaultConfiguration];
BOOL initialized = [AIBudsSDK initWithBleSDKs:@[[ABMateSDK shared]]
                                 configuration:configuration
                                      delegate:self];
if (!initialized) {
    return;
}
```

For exact selectors in the installed version, use Xcode completion or the generated public Swift/Objective-C interface. Do not infer selectors from private symbols.

## Verification matrix

| Case | Expected observable behavior |
|---|---|
| Required Bluetooth description missing | Initialization returns `false`; scanning is not started. |
| Initialization called twice | The second call is rejected; the app does not create a second SDK owner. |
| Bluetooth denied or restricted | The app uses the public iOS permission state to present actionable guidance and does not loop scanning. |
| Scan times out with no device | Empty state is stable and the user can explicitly retry. |
| Repeated discovery update | The existing row is updated; no duplicate connection attempt starts. |
| Discovered device cannot be converted | The app does not force a connection and reports unsupported/invalid discovery. |
| Connect requested | UI enters connecting state, but features remain disabled until `deviceDidReady(_:)`. |
| Device disconnects | State changes through the callback; app-owned work is cancelled or paused safely. |
| Optional capability unsupported | The feature is hidden or rejected without a force cast. |
| Voice authentication succeeds | The public delegate callback reports success and UI updates on the main queue. |
| Voice authentication fails with nil error | The app shows a stable fallback message. |
| App-owned AI selected | No bundled AIBuds AI provider is initialized; secrets remain in the app's AI client. |
