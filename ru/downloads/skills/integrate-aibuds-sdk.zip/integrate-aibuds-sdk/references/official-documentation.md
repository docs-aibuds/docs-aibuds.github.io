# Official documentation routing and citation policy

## Public sources

The following are public, developer-facing sources and may be cited in answers:

- Documentation home: <https://docs-aibuds.github.io/>
- Documentation: `https://docs-aibuds.github.io/docs/...`
- Public API Reference: <https://docs-aibuds.github.io/api-reference/>
- Public SDK repository linked by the documentation site, when the developer explicitly needs packaging or release information.

These sources do not weaken the non-disclosure boundary. Cite their public contracts and guidance, but do not supplement them with private source findings, unpublished behavior, inferred packet details, or implementation explanations.

## Retrieval policy

Official documentation can change independently of a copied skill package.

1. Determine the developer's requested capabilities first.
2. Open only the directly relevant official pages when web access is available. Prefer the documentation page over search-result summaries or third-party tutorials.
3. Verify that the page still supports the proposed module, call order, and public API name before relying on it.
4. Prefer the developer's language through the site's locale selector when that localized page is available. Do not invent a translated path that was not verified.
5. Link the exact task page next to the step it supports. Do not replace useful task links with a generic homepage link.
6. Keep citations selective: normally one installation or quick-start page plus one page per advanced capability is sufficient.
7. When current official documentation conflicts with a cached example in this skill, follow the current public documentation and clearly note any version requirement. Never bridge the conflict with internal implementation knowledge.
8. If the site cannot be reached, continue from the public contracts embedded in this package, say that the live page could not be reverified, and provide the stable official URL only when it is listed below.

## Page router

| Developer need | Relevant official page |
|---|---|
| Documentation entry point | <https://docs-aibuds.github.io/> |
| Installation and module setup | <https://docs-aibuds.github.io/docs/getting-started/installation> |
| SDK configuration | <https://docs-aibuds.github.io/docs/getting-started/configuration> |
| First working integration | <https://docs-aibuds.github.io/docs/getting-started/quickstart> |
| AllInOne integration | <https://docs-aibuds.github.io/docs/advanced-topics/all-in-one> |
| Bring Your Own AI | <https://docs-aibuds.github.io/docs/advanced-topics/bring-your-own-ai> |
| Report self-owned AI authorization | <https://docs-aibuds.github.io/docs/core/auth/notify-ai-auth-result> |
| On-device voice-assistant authentication | <https://docs-aibuds.github.io/docs/advanced-topics/on-device-voice-assistant-authentication> |
| AI services overview | <https://docs-aibuds.github.io/docs/ai/overview> |
| AI provider selection | <https://docs-aibuds.github.io/docs/ai/select-provider> |
| AI chat | <https://docs-aibuds.github.io/docs/ai/ai-chat> |
| AI audio recording | <https://docs-aibuds.github.io/docs/ai/ai-audio-recording> |
| Streaming ASR | <https://docs-aibuds.github.io/docs/ai/streaming-asr> |
| Simultaneous interpretation | <https://docs-aibuds.github.io/docs/ai/simultaneous-interpretation> |
| Video stabilization | <https://docs-aibuds.github.io/docs/advanced-topics/video-stabilization> |
| AI Dashboard | <https://docs-aibuds.github.io/docs/advanced-topics/ai-dashboard> |
| Crash Reporter | <https://docs-aibuds.github.io/docs/advanced-topics/crash-reporter> |
| Common troubleshooting | <https://docs-aibuds.github.io/docs/troubleshooting/common-issues> |
| Public symbols and signatures | <https://docs-aibuds.github.io/api-reference/aibuds-sdk> |

For a core device feature not listed here, navigate from the official documentation's Core Features section or search the official site. Verify the resulting URL before citing it.

## Citation examples

Good:

> 自有 AI 完成鉴权后，应通过 `DeviceServiceAuthAPI.reportSelfAiServiceAuthResult` 仅向设备报告成功或失败；凭据仍保留在 App 自己的服务层。详见 [Bring Your Own AI Service](https://docs-aibuds.github.io/docs/advanced-topics/bring-your-own-ai) 和 [Report Self-AI Authorization](https://docs-aibuds.github.io/docs/core/auth/notify-ai-auth-result)。

Avoid:

- giving only the home page when a task page exists;
- dumping a long unrelated link list at the end;
- citing an internal repository path;
- presenting a public API Reference page as evidence for undocumented runtime behavior;
- copying large sections of official prose instead of summarizing and linking.
