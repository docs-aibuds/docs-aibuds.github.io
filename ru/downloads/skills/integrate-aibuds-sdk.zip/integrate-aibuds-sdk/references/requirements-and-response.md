# Requirements and response contract

## Resolve the developer's intent

Build a capability profile from the request and the consumer project. Do not force the developer through a questionnaire when the repository or prompt already answers a question.

Decisive inputs:

| Input | Why it matters |
|---|---|
| Complete integration or selected features | Chooses AllInOne versus modular installation. |
| Device protocol/provider | Core defines public connectivity contracts, while a compatible provider performs device recognition and connection. |
| App-owned AI or AIBuds AI provider | App-owned AI normally omits AIBuds AI modules; provider-backed features select only the named provider module. |
| On-device voice-assistant authentication | Adds the VoiceAssistant module and public bridge registration. |
| Swift or Objective-C | Changes imports, delegate declarations, and code syntax. |
| CocoaPods source and SDK version | Determines the exact dependency declaration. Never guess either value. |
| Foreground-only or background BLE | Determines whether `bluetooth-central` is needed. |
| Existing connection manager and UI architecture | Integration must fit the app rather than create a competing owner. |

When one of these is unknown and materially changes the answer, ask a concise question. When it does not block a useful answer, state the assumption and show how the alternative differs.

## Common routing decisions

### Complete feature set

Choose AllInOne when the developer explicitly prioritizes the shortest setup or wants the complete supported suite. Explain that it has the largest dependency footprint and configures bundled providers.

### Device connection with app-owned AI

Choose the compatible connection provider, commonly the `ABMate` subspec for devices using that public provider. Do not add `AI`, `AI/Core`, `AI/StarBurst`, or `AI/MltCloud` merely because the app has AI features. The app may hand public device events or media data to its own AI boundary.

Follow the public [Bring Your Own AI Service](https://docs-aibuds.github.io/docs/advanced-topics/bring-your-own-ai) workflow:

1. Connect the device and wait for the required public feature APIs to become ready.
2. Authenticate the app's own AI service entirely inside the host app.
3. Check `DeviceServiceAuthAPI` support and call `reportSelfAiServiceAuthResult(_:)` with `true` only when the service is ready; report `false` after authentication failure or when the service becomes unavailable.
4. Continue the documented device-driven AI event, requested SCO or Opus audio path, session lifecycle, stop handling, and cleanup for the selected feature.

The completion of `reportSelfAiServiceAuthResult` reports whether the Boolean result was delivered to the device. It does not authenticate the app's AI service and must never carry tokens, keys, or credentials. Link the [Report Self-AI Authorization](https://docs-aibuds.github.io/docs/core/auth/notify-ai-auth-result) guide when showing this call.

Before writing the remaining AI handoff, determine which public feature flow the app needs: AI Chat, AI Audio Recording, Streaming ASR, Simultaneous Interpretation, or another documented capability. Do not invent a generic stream API, and do not let the app override the audio channel selected by the device.

### Device connection, app-owned AI, and on-device voice-assistant authentication

Start with the connection-only selection and add `VoiceAssistant`. Register `VoiceAssistantSDK.bridgePlugin` through `AIBudsSDK.setOnDeviceVoiceAssistantPlugin(_:)` during startup, before authentication can begin. Continue receiving the result through the public SDK/device delegate callback.

The bundled VoiceAssistant module owns the authentication operation behind its public bridge. Do not describe its algorithm, exchanged payloads, vendor library, keys, or transport sequence.

### Custom connection provider

Use `Core` plus the developer's documented `BleConnectSDK` implementation. Require the provider instance in `AIBudsSDK.initialize(_:configuration:delegate:)`. Do not imply that `Core` alone can recognize an arbitrary physical device.

## Response shape

Use the smallest structure that remains complete:

1. **需求理解** — restate selected capabilities, assumptions, and exclusions.
2. **模块方案** — list the exact subspecs and explain each selection and omission.
3. **安装** — give a version-consistent Podfile snippet and the developer's normal install command.
4. **工程配置** — deployment target, Bluetooth descriptions, and conditional background mode.
5. **初始化** — show imports, provider/plugin registration, configuration, delegate ownership, and `Bool` handling.
6. **功能链路** — show scan, discovered-device conversion, connection, readiness, and only the requested optional capabilities.
7. **自有 AI 边界** — show host authentication, Boolean result reporting through `DeviceServiceAuthAPI`, the exact documented feature input, and app-owned credential/request handling.
8. **验证** — provide observable checkpoints and failure cases.
9. **排障** — diagnose through public return values, callbacks, permissions, dependency resolution, and version consistency.
10. **官方资料** — link the exact installation and selected feature pages next to the relevant guidance; avoid an unrelated link dump.

For a conceptual question, answer directly and omit irrelevant sections. For implementation requests, include complete code around the affected boundary, but do not fabricate application types.

## Non-disclosure responses

If the developer requests a private command, packet format, encryption key, internal class, source path, authentication algorithm, or reverse engineering:

1. State that SDK internals cannot be provided.
2. Name the public API or callback that fulfills the supported goal.
3. Offer integration code, observable diagnostics, or a minimal reproduction using that public boundary.

Do not confirm a guessed internal mechanism. Do not leak details while explaining the refusal.
