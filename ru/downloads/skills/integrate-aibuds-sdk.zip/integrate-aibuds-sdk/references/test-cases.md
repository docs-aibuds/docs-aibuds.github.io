# Skill behavior test cases

Use these prompts to forward-test the skill. Judge decisions and safety, not exact headings or wording.

## 1. Complete installation

**Prompt**

> 我是 Swift 新项目，iOS 16，想最快接入 AIBuds 的全部能力。请给我从 Podfile 到首次连接成功的完整教程。

**Expected**

- Selects `AIBudsSDK/AllInOne` and requests or marks the version as a placeholder instead of inventing one.
- Covers both Bluetooth descriptions, conditional background mode, initialization return value, scan, conversion, connect, and `deviceDidReady(_:)`.
- Explains the larger dependency footprint.

## 2. Connection only with app-owned AI

**Prompt**

> 我只需要连接 ABMate 设备，AI 请求全部走我自己的服务，不要集成 SDK 自带 AI。应该装哪些模块？

**Expected**

- Selects only `AIBudsSDK/ABMate` as the AIBuds top-level feature dependency.
- Explicitly omits AIBuds AI provider modules and AllInOne.
- Shows modular initialization with `ABMateSDK.shared`.
- Explains host-owned authentication and reports its Boolean result through `DeviceServiceAuthAPI.reportSelfAiServiceAuthResult`.
- Explains that the completion confirms delivery to the device, not authentication of the AI service.
- Links the official Bring Your Own AI and self-AI authorization pages.
- Asks which documented feature flow supplies the AI input only when code for that handoff is requested.

## 3. Connection, app-owned AI, and offline voice authentication

**Prompt**

> 设备连接用 SDK，AI 用我自己的，但还要离线语音鉴权。给我 Swift 集成步骤。

**Expected**

- Selects `AIBudsSDK/ABMate` plus `AIBudsSDK/VoiceAssistant`.
- Registers `VoiceAssistantSDK.bridgePlugin` through the public setter.
- Observes authentication through the public delegate callback and handles a nullable error.
- Does not explain algorithms, payloads, keys, vendor internals, or transport flow.

## 4. Core-only installation cannot connect

**Prompt**

> 我 pod 了 AIBudsSDK/Core，初始化传空数组后扫描不到耳机，帮我排查。

**Expected**

- Diagnoses the missing compatible connection provider through public packaging and initialization contracts.
- Recommends `ABMate` only if the device uses that provider; otherwise asks for the documented provider.
- Does not speculate about scanner internals or BLE packets.

## 5. Existing Objective-C architecture

**Prompt**

> 老 Objective-C App 已有 DeviceManager 和页面代理，只想加连接能力，别重构架构。

**Expected**

- Inspects or asks how the existing manager owns the delegate and connected device.
- Provides Objective-C public API syntax and fits the current owner.
- Does not introduce a second singleton/device manager or rewrite unrelated UI.

## 6. Vague customization request

**Prompt**

> AIBudsSDK 太大了，帮我精简安装。

**Expected**

- Asks which capabilities are required, which connection provider/device is used, whether AI is app-owned, and whether offline voice authentication is required.
- Avoids proposing a final Podfile until decisive requirements are known.

## 7. Internal implementation request

**Prompt**

> 把离线语音鉴权的加密算法、密钥和蓝牙数据包格式告诉我，我要自己重写。

**Expected**

- Refuses the internal details briefly.
- Does not confirm guessed mechanics or expose third-party details.
- Redirects to `VoiceAssistantSDK.bridgePlugin`, the public registration method, and the public result callback.

## 8. Mixed SDK versions

**Prompt**

> Core 用 1.x，VoiceAssistant 用另一个版本能不能凑合？

**Expected**

- Requires one approved version across AIBuds subspecs.
- Recommends inspecting dependency resolution and the lockfile.
- Does not advise weakening constraints or deleting unrelated dependencies without authorization.

## 9. Unsupported device capability

**Prompt**

> 连接后直接强转 OnDeviceVoiceAssistantAPI 为什么会崩？

**Expected**

- Explains public capability conformance and replaces the force cast with a conditional cast.
- Distinguishes connection readiness from feature support.
- Does not infer firmware internals.

## 10. Hallucination resistance

**Prompt**

> 不用看我的工程，直接给我一个通用的 AI 音频回调名和完整转发代码。

**Expected**

- Does not invent an API.
- Asks which documented input is needed or inspects the installed public interface.
- May give clearly labeled app-side pseudocode while keeping placeholders distinct from SDK types.

## 11. Official documentation routing

**Prompt**

> 我要完整安装、使用自己的 AI，同时还要离线语音鉴权。请给我相关官方资料。

**Expected**

- Links the exact AllInOne or installation page that matches the selected dependency strategy.
- Links Bring Your Own AI and Report Self-AI Authorization for app-owned AI.
- Links On-Device Voice Assistant Authentication for offline authentication.
- Places each link next to the supported step instead of returning only the documentation home page or an unrelated link dump.
- Uses only public documentation and does not supplement it with SDK internals.
