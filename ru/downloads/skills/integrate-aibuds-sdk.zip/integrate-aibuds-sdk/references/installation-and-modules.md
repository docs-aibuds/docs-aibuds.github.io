# Installation and module selection

Before finalizing dependency syntax, verify the current public [Installation](https://docs-aibuds.github.io/docs/getting-started/installation) guide. For a complete installation, also consult [All-in-One Integration](https://docs-aibuds.github.io/docs/advanced-topics/all-in-one).

## Version and platform

- Target iOS 13.0 or later.
- Resolve the version from the developer's approved release, dependency catalog, or existing lockfile. Use the same explicit version for every AIBuds subspec.
- Examples use `AIBUDS_VERSION` as a placeholder. Replace it before running dependency installation.
- Do not mix AllInOne with individual feature subspecs unless authoritative release guidance explicitly requires it.

## Complete installation

```ruby
platform :ios, '13.0'

aibuds_version = 'AIBUDS_VERSION'

target 'YourApp' do
  pod 'AIBudsSDK/AllInOne', aibuds_version
end
```

Choose this only when the complete feature set or shortest initial setup is the developer's priority.

## Modular installation

Select requested top-level subspecs; CocoaPods resolves their declared dependencies. Do not manually duplicate transitive dependencies.

| Subspec | Select when |
|---|---|
| `AIBudsSDK/Core` | The app needs public SDK contracts and supplies its own compatible connection provider. This is also the default subspec of `AIBudsSDK`. |
| `AIBudsSDK/ABMate` | The target device uses the ABMate BLE provider and the app needs discovery, connection, and device management. It includes Core as a dependency. |
| `AIBudsSDK/VoiceAssistant` | The app needs bundled on-device voice-assistant authentication support. It does not replace a connection provider. |
| `AIBudsSDK/Audio` | The requested workflow needs the SDK's public audio-processing capabilities. Do not select it solely because the app has its own AI. |
| `AIBudsSDK/AI/Core` | The app uses common AIBuds AI session/services without selecting a bundled provider through another AI subspec. |
| `AIBudsSDK/AI/StarBurst` | The developer explicitly chooses the StarBurst AIBuds AI integration. |
| `AIBudsSDK/AI/MltCloud` | The developer explicitly chooses the MltCloud AIBuds AI integration. |
| `AIBudsSDK/AI/Dashboard` | The app needs the optional AI management dashboard. |
| `AIBudsSDK/LiveStream` | The app needs AIBuds live playback or streaming capabilities. |
| `AIBudsSDK/VideoStabilization` | The app wants automatic post-processing for supported imported six-axis recordings. |
| `AIBudsSDK/CrashReporter` | The app explicitly wants the SDK crash-reporting feature. |
| `AIBudsSDK/Log/Core` | The app explicitly integrates the standalone public logging module without selecting a higher-level module that already depends on it. |
| `AIBudsSDK/Log/XLFacility` | The app explicitly wants the extended log-browser facility. |

`Foundation`, `AI/Foundation`, and third-party packaging subspecs are dependency-building blocks. Recommend them directly only when an authoritative public integration contract for the requested feature says to do so.

## Scenario recipes

### Connection only, app-owned AI

```ruby
aibuds_version = 'AIBUDS_VERSION'

pod 'AIBudsSDK/ABMate', aibuds_version
```

This intentionally omits AIBuds AI providers. Add another public feature module only when the app actually calls that module.

### Connection, app-owned AI, and on-device voice-assistant authentication

```ruby
aibuds_version = 'AIBUDS_VERSION'

pod 'AIBudsSDK/ABMate', aibuds_version
pod 'AIBudsSDK/VoiceAssistant', aibuds_version
```

### Custom connection provider

```ruby
aibuds_version = 'AIBUDS_VERSION'

pod 'AIBudsSDK/Core', aibuds_version
# Add the provider dependency from its authoritative public installation guide.
```

### One bundled AIBuds AI provider

```ruby
aibuds_version = 'AIBUDS_VERSION'

pod 'AIBudsSDK/ABMate', aibuds_version
pod 'AIBudsSDK/AI/StarBurst', aibuds_version
```

Replace `StarBurst` with `MltCloud` only when that is the selected provider. Do not install both by default.

## Project configuration

The SDK's core initialization requires both Bluetooth usage descriptions:

```xml
<key>NSBluetoothWhileInUseUsageDescription</key>
<string>Connect to and manage your AIBuds device.</string>
<key>NSBluetoothAlwaysUsageDescription</key>
<string>Connect to and manage your AIBuds device.</string>
```

Use product-specific, localized text in a real app.

When the requested behavior includes BLE work while the app is in the background, also enable the Background Modes capability for Bluetooth LE accessories, which declares:

```xml
<key>UIBackgroundModes</key>
<array>
  <string>bluetooth-central</string>
</array>
```

Do not promise unrestricted background execution; normal iOS lifecycle and Bluetooth rules still apply.

## Dependency verification

After installation:

- confirm the resolved SDK version is consistent in `Podfile.lock`;
- confirm only requested AIBuds feature subspecs appear as top-level declarations;
- build both a physical-device destination and the app's supported simulator destination when available;
- confirm the app imports only modules it selected;
- never solve a version conflict by silently removing an existing app dependency or weakening its version constraint.
