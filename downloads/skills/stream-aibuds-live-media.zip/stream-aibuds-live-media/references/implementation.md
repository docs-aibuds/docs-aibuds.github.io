# Stream Live Media from AIBuds: public integration reference

## Scope and public contracts

Use this reference to start and stop supported RTSP or JPEG live streams. Confirm exact declarations in the installed SDK version before editing the consumer app.

- `LiveStreamingAPI`
- `supportsRTSPLiveStreaming`
- `supportsJPEGImageLiveStreaming`
- `startRTSPLiveStreaming`
- `startJPEGImageLiveStreaming`
- `stopLiveStreaming`
- `AIBudsLiveStreamingOpusAudioDataReceivedHandler`
- `LiveStreamer`, `LiveStreamerConfig`, `pushJpegFrame`, `pushPcmAudio`

## Official documentation

- [docs/core/live-streaming/rtsp ](https://docs-aibuds.github.io/docs/core/live-streaming/rtsp)
- [docs/core/live-streaming/jpeg ](https://docs-aibuds.github.io/docs/core/live-streaming/jpeg)
- [docs/core/live-streaming/stop ](https://docs-aibuds.github.io/docs/core/live-streaming/stop)
- [AIBuds SDK API Reference](https://docs-aibuds.github.io/api-reference/aibuds-sdk)
- [Common troubleshooting](https://docs-aibuds.github.io/docs/troubleshooting/common-issues)


## Portable workflow

1. Initialize only the documented module needed for this feature.
2. Wait for the public ready callback and cast the selected `DeviceConvertible` to `LiveStreamingAPI` safely.
3. Validate user input and public capability/range information before calling the SDK.
4. Serialize mutually exclusive operations and keep callback/session owners alive for as long as the public contract requires.
5. Treat callback success and error as the operation result. Move UI work to the main queue and use public connection callbacks as the source of truth.
6. On cancellation, view exit, background transition, or disconnect, stop only through a documented stop/cancel API and clear application-owned state.

## Swift pattern

Adapt names such as `device`, handlers, models, and UI functions to the consumer app. Do not copy repository-specific helpers.

```swift
guard device.isConnectedAndReady else { return }
// guard let featureDevice = device as? LiveStreamingAPI else { return }

guard streamDevice.supportsRTSPLiveStreaming else { return }
streamDevice.startRTSPLiveStreaming(withParams: params, /* documented phase and session handlers */)
// Always pair a successful start with stopLiveStreaming().
```

## Objective-C pattern

Use the Objective-C names exposed by the installed generated interface; availability and nullability remain authoritative.

```objective-c
if (!device.isConnectedAndReady) { return; }
// Check conformsToProtocol: before casting to the public protocol.

if (!streamDevice.supportsRTSPLiveStreaming) { return; }
[streamDevice startRTSPLiveStreamingWithParams:params /* documented phase and session handlers */];
// Always pair a successful start with stopLiveStreaming.
```

## JPEG audio and migration

In SDK 1.0.1-beta.10 and later, the JPEG start call requires an `opusDataReceivedHandler` argument. Pass `nil` when audio is not needed. On compatible devices the callback provides Opus data and optional decoded PCM data; it does not guarantee audio on every JPEG stream. Skip PCM playback or publishing when the decoded data is nil or empty. Do not assume callbacks run on the main queue.

The following patterns use application-owned handlers with the installed SDK's public callback types:

```swift
guard device.isConnectedAndReady,
      let streamDevice = device as? LiveStreamingAPI,
      streamDevice.supportsJPEGImageLiveStreaming else { return }
streamDevice.startJPEGImageLiveStreaming(
    withSessionStartCompletionHandler: startHandler,
    jpegDataReceivedHandler: jpegHandler,
    opusDataReceivedHandler: nil,
    sessionFinishHandler: finishHandler
)
```

```objective-c
if (!device.isConnectedAndReady || ![device conformsToProtocol:@protocol(LiveStreamingAPI)]) { return; }
id<LiveStreamingAPI> streamDevice = (id<LiveStreamingAPI>)device;
if (!streamDevice.supportsJPEGImageLiveStreaming) { return; }
[streamDevice startJPEGImageLiveStreamingWithSessionStartCompletionHandler:startHandler
                                                  jpegDataReceivedHandler:jpegHandler
                                                  opusDataReceivedHandler:nil
                                                     sessionFinishHandler:finishHandler];
```

To receive audio, replace `nil` with a Swift closure taking `(opusData, decodedPcmAudioData)` or an Objective-C block taking `(NSData *opusData, NSData * _Nullable decodedPcmAudioData)`. Keep frame/audio processing off the main queue and move presentation changes onto it.

## Optional RTMP publishing

Install the public Live Stream module only if publishing is requested. For JPEG/PCM input, configure an application-owned `LiveStreamer` with an output URL and a `LiveStreamerConfig`:

```swift
streamer.configure(outputURL: outputURL, config: config)
streamer.startStreaming()
// Feed only after the public streamer state reports streaming.
streamer.pushJpegFrame(jpegData)
streamer.pushPcmAudio(pcmData)
// On exit, failure, or disconnect:
streamer.stopStreaming()
```

```objective-c
[streamer configureWithOutputURL:outputURL config:config];
[streamer startStreaming];
// Feed only after the public streamer state reports streaming.
[streamer pushJpegFrame:jpegData];
[streamer pushPcmAudio:pcmData];
// On exit, failure, or disconnect:
[streamer stopStreaming];
```

These calls illustrate separate lifecycle phases, not a sequence to run without waiting for startup. Route JPEG callbacks to `pushJpegFrame` and nonempty decoded PCM callbacks to `pushPcmAudio` only while publishing. Set `publishAudio` according to the requested stream and match `inputAudioSampleRate` and `inputAudioChannels` to the supplied PCM S16LE data. The defaults are 16000 Hz and one channel; verify the actual input format rather than assuming it for arbitrary audio sources.

RTSP relay uses the separate `configure(inputURL:outputURL:config:)` overload. Do not use the removed `configure(url:config:)` form with the current SDK. Stopping RTMP publishing and stopping the device stream are separate operations: call `stopStreaming()` and `stopLiveStreaming()` for the resources the app owns. Keep the streamer alive throughout publishing.

## Error and lifecycle rules

- Do not force-cast optional capabilities or assume a callback queue.
- Prevent repeated submissions while an operation is in flight.
- Dispatch presentation/state mutations to the main queue.
- Show `localizedDescription` when a public error exists and a stable fallback otherwise.
- Do not guess device state after a command; reconcile it through public properties and callbacks.
- Keep credentials, private endpoints, and app-owned AI/network implementations outside SDK calls.

## Verification matrix

| Case | Expected check |
|---|---|
| Device or service unavailable | Reject cleanly without calling an unsupported API. |
| Success | Update UI on the main queue and refresh public state when relevant. |
| Failure with error | Present the public localized error without internal interpretation. |
| Failure without error | Present a stable application-owned fallback message. |
| Repeated action | Keep at most one incompatible request/session in flight. |
| Disconnect or lifecycle exit | Cancel/stop through public API when available and clear app state. |
| The selected transport is publicly reported as supported. | Confirm the app behaves deterministically and reports public errors safely. |
| Frames are processed off the main thread; UI updates return to it. | Confirm the app behaves deterministically and reports public errors safely. |
| Stop runs on exit, failure, and disconnect. | Confirm the app behaves deterministically and reports public errors safely. |
| JPEG stream without audio | Accept frames with a nil audio handler; do not wait for audio to declare success. |
| JPEG stream with audio | Handle nil/empty decoded PCM without crashing and keep UI changes on the main queue. |
| RTMP publishing | Wait for streaming state before feeding frames/audio, match PCM format, and stop both owned sessions on exit. |

## Information boundary

Explain what the public call accepts, what its public callback reports, and how the app should react. Do not describe transport details, command encoding, SDK source structure, private dependencies, or internal execution paths.
