# Implement AIBuds AI Chat: public integration reference

## Scope and public contracts

Use this reference to manage AI chat sessions, messages, and streamed answers. Confirm exact declarations in the installed SDK version before editing the consumer app.

- `AIBudsAISDK`
- `startAIChat`
- `send(question:config:onStartAnswering:onAnswer:onFinishAnswering:onError:)`
- `stopAIChat`

## Official documentation

- [docs/ai/ai-chat ](https://docs-aibuds.github.io/docs/ai/ai-chat)
- [docs/ai/session-events ](https://docs-aibuds.github.io/docs/ai/session-events)
- [docs/advanced-topics/bring-your-own-ai ](https://docs-aibuds.github.io/docs/advanced-topics/bring-your-own-ai)
- [AIBuds SDK API Reference](https://docs-aibuds.github.io/api-reference/aibuds-sdk)
- [Common troubleshooting](https://docs-aibuds.github.io/docs/troubleshooting/common-issues)

## Portable workflow

1. Initialize only the documented module needed for this feature.
2. Initialize the documented SDK-level service once, configure only public prerequisites, and retain any public session owner for its documented lifetime.
3. Validate user input and public capability/range information before calling the SDK.
4. Serialize mutually exclusive operations and keep callback/session owners alive for as long as the public contract requires.
5. Treat callback success and error as the operation result. Move UI work to the main queue and use public connection callbacks as the source of truth.
6. On cancellation, view exit, background transition, or disconnect, stop only through a documented stop/cancel API and clear application-owned state.

## Swift pattern

Adapt names such as `device`, handlers, models, and UI functions to the consumer app. Do not copy repository-specific helpers.

```swift
// Initialize and configure the documented SDK-level service before use.


AIBudsAISDK.startAIChat(config, onStartSuccess: started, onStartFailure: failed, onChatData: chatData, onIntent: intent, onVoiceData: voiceData, onEvent: event, onError: runtimeError, onFinish: finished)
AIBudsAISDK.send(question: question, config: askingConfig, onStartAnswering: answerStarted, onAnswer: answer, onFinishAnswering: answerFinished, onError: answerFailed)
// Stop the session on exit.
```

## Objective-C pattern

Use the Objective-C names exposed by the installed generated interface; availability and nullability remain authoritative.

```objective-c
// Initialize and configure the documented SDK-level service before use.


[AIBudsAISDK startAIChatWithConfig:config onStartSuccess:started onStartFailure:failed onChatData:chatData onIntent:intent onVoiceData:voiceData onEvent:event onError:runtimeError onFinish:finished];
[AIBudsAISDK sendQuestion:question config:askingConfig onStartAnswering:answerStarted onAnswer:answer onFinishAnswering:answerFinished onError:answerFailed];
// Stop the session on exit.
```

## Error and lifecycle rules

- Do not force-cast optional capabilities or assume a callback queue.
- Prevent repeated submissions while an operation is in flight.
- Dispatch presentation/state mutations to the main queue.
- Show `localizedDescription` when a public error exists and a stable fallback otherwise.
- Do not guess device state after a command; reconcile it through public properties and callbacks.
- Keep credentials, private endpoints, and app-owned AI/network implementations outside SDK calls.

## Verification matrix

| Case | Expected check |
|---|---|
| Device or service unavailable | Reject cleanly without calling an unsupported API. |
| Success | Update UI on the main queue and refresh public state when relevant. |
| Failure with error | Present the public localized error without internal interpretation. |
| Failure without error | Present a stable application-owned fallback message. |
| Repeated action | Keep at most one incompatible request/session in flight. |
| Disconnect or lifecycle exit | Cancel/stop through public API when available and clear app state. |
| Session ownership is explicit. | Confirm the app behaves deterministically and reports public errors safely. |
| Streamed output is ordered and main-thread UI safe. | Confirm the app behaves deterministically and reports public errors safely. |
| App-owned AI remains an app concern when selected. | Confirm the app behaves deterministically and reports public errors safely. |

## Information boundary

Explain what the public call accepts, what its public callback reports, and how the app should react. Do not describe transport details, command encoding, SDK source structure, private dependencies, or internal execution paths.
