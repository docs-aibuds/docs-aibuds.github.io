# Update AIBuds Firmware: public integration reference

## Scope and public contracts

Use this reference to implement automatic or explicitly selected device OTA through public AIBuds APIs. Confirm exact declarations in the installed SDK version before editing the consumer app.

- `DeviceOtaAPI`
- `otaProtocolCapability`
- `otaBatteryLimit`
- `OtaProtocolCapability`
- `OtaProtocolKind`
- `OtaConfiguration`
- `startOta(withFilePath:startHandler:progressHandler:completionHandler:)`
- `startOta(withFilePath:configuration:startHandler:progressHandler:completionHandler:)`
- `AIBudsSDK.otaPlugin(for:)`

## Official documentation

- [docs/core/ota/firmware-update](https://docs-aibuds.github.io/docs/core/ota/firmware-update)
- [AIBuds SDK API Reference](https://docs-aibuds.github.io/api-reference/aibuds-sdk)
- [Common troubleshooting](https://docs-aibuds.github.io/docs/troubleshooting/common-issues)

## What this skill can decide

The skill can derive selectable OTA methods from `otaProtocolCapability`, filter plugin-backed methods by public plugin registration, and choose between automatic and configured starts. It can also implement application-owned preflight checks, progress presentation, error handling, and operation-state cleanup.

It cannot inspect firmware contents to guarantee compatibility, add support that the device did not report, install an unavailable binary dependency, or explain private transport behavior. `DeviceOtaAPI` has no unified public cancellation method, so the app must not present a fake cancel action that only resets local UI.

## Protocol-selection policy

Use the basic overload by default. The SDK automatically selects the only supported method and defaults to ABMate for compatibility when capability information is absent or ambiguous.

Show a protocol selector only when all of the following are true:

1. `otaProtocolCapability` reports more than one method.
2. Every displayed plugin-backed method has a registered plugin.
3. Product requirements intentionally allow the user to choose.

After an explicit choice, create a fresh `OtaConfiguration`, assign its `otaProtocol`, and call the configured overload. Never infer support only because a plugin is installed: device capability and plugin availability are separate requirements.

## Swift pattern

Adapt state and presentation names to the consumer app.

```swift
guard device.isConnectedAndReady,
      let otaDevice = device as? DeviceOtaAPI,
      batteryLevel >= otaDevice.otaBatteryLimit else {
    return
}

let choices: [OtaProtocolKind]
switch otaDevice.otaProtocolCapability {
case .abmateAndFitcloudPro:
    choices = AIBudsSDK.otaPlugin(for: .fitcloudPro) == nil
        ? [.abmate]
        : [.abmate, .fitcloudPro]
case .fitcloudPro:
    choices = AIBudsSDK.otaPlugin(for: .fitcloudPro) == nil ? [] : [.fitcloudPro]
case .jieli:
    choices = AIBudsSDK.otaPlugin(for: .jieli) == nil ? [] : [.jieli]
case .none, .abmate:
    choices = [.abmate]
@unknown default:
    choices = [.abmate]
}

guard !choices.isEmpty else {
    // Present an application-owned "required OTA plugin is unavailable" error.
    return
}

if choices.count == 1 {
    // Preserve SDK automatic selection when the user has nothing to choose.
    otaDevice.startOta(
        withFilePath: firmwarePath,
        startHandler: started,
        progressHandler: progress,
        completionHandler: completed
    )
} else {
    let configuration = OtaConfiguration()
    configuration.otaProtocol = selectedProtocol
    otaDevice.startOta(
        withFilePath: firmwarePath,
        configuration: configuration,
        startHandler: started,
        progressHandler: progress,
        completionHandler: completed
    )
}
```

## Objective-C pattern

Use the Objective-C names exposed by the installed generated interface.

```objective-c
if (!device.isConnectedAndReady ||
    ![device conformsToProtocol:@protocol(AIBudsDeviceOtaAPI)]) {
    return;
}

id<AIBudsDeviceOtaAPI> otaDevice = (id<AIBudsDeviceOtaAPI>)device;
if (batteryLevel < otaDevice.otaBatteryLimit) {
    return;
}

NSMutableArray<NSNumber *> *choices = [NSMutableArray array];
switch (otaDevice.otaProtocolCapability) {
    case AIBudsOtaProtocolCapabilityAbmateAndFitcloudPro:
        [choices addObject:@(AIBudsOtaProtocolKindAbmate)];
        if ([AIBudsSDK otaPluginForProtocolKind:AIBudsOtaProtocolKindFitcloudPro]) {
            [choices addObject:@(AIBudsOtaProtocolKindFitcloudPro)];
        }
        break;
    case AIBudsOtaProtocolCapabilityFitcloudPro:
        if ([AIBudsSDK otaPluginForProtocolKind:AIBudsOtaProtocolKindFitcloudPro]) {
            [choices addObject:@(AIBudsOtaProtocolKindFitcloudPro)];
        }
        break;
    case AIBudsOtaProtocolCapabilityJieli:
        if ([AIBudsSDK otaPluginForProtocolKind:AIBudsOtaProtocolKindJieli]) {
            [choices addObject:@(AIBudsOtaProtocolKindJieli)];
        }
        break;
    default:
        [choices addObject:@(AIBudsOtaProtocolKindAbmate)];
        break;
}

if (choices.count == 1) {
    [otaDevice startOtaWithFilePath:firmwarePath
                      startHandler:started
                   progressHandler:progress
                 completionHandler:completed];
} else if (choices.count > 1) {
    AIBudsOtaConfiguration *configuration = [[AIBudsOtaConfiguration alloc] init];
    configuration.otaProtocol = selectedProtocol;
    [otaDevice startOtaWithFilePath:firmwarePath
                     configuration:configuration
                      startHandler:started
                   progressHandler:progress
                 completionHandler:completed];
}
```

## Operation and lifecycle rules

- Validate that the firmware URL is a readable local file before starting, but leave firmware-format and device-compatibility validation to documented SDK results.
- Prevent repeated starts while an OTA operation is active; disable file and protocol selection until a terminal callback.
- Treat a failed start callback as terminal unless the installed API explicitly documents otherwise.
- Clamp displayed progress to `0...1` and dispatch UI updates to the main queue.
- Restore application-owned controls after start failure or completion failure as well as success.
- On disconnect, mark local state as interrupted and wait for public connection callbacks; do not guess whether device-side recovery succeeded.
- Do not call `OtaPlugin.cancel` as a substitute for a device-level cancellation contract, and do not reset the UI while an OTA may still be active.

## Verification matrix

| Case | Expected check |
|---|---|
| Device lacks `DeviceOtaAPI` | Hide or disable OTA without a force cast. |
| Capability reports one method | Do not show a selector; call the automatic overload. |
| Capability reports ABMate and FitCloud Pro | Offer both only when the FitCloud Pro plugin is registered. |
| Plugin-backed single method is unavailable | Block the start and explain the missing public dependency. |
| Explicit selection | Pass a fresh `OtaConfiguration` containing a listed protocol. |
| Low battery, unreadable file, not ready, or duplicate start | Reject before calling the SDK. |
| Start failure or completion failure | Restore controls and present `localizedDescription` or a stable fallback. |
| Progress and success | Update UI on the main queue and retain the operation owner until completion. |
| Disconnect | Clear application-owned active state through observed callbacks without claiming device recovery. |
| User requests cancellation | Explain that the installed `DeviceOtaAPI` has no unified public cancel method. |

## Information boundary

Explain protocol capability, plugin availability, configuration, callbacks, public errors, and application behavior. Do not describe packet layout, BLE command order, authentication algorithms, third-party SDK internals, or private retry/reconnection mechanics.
