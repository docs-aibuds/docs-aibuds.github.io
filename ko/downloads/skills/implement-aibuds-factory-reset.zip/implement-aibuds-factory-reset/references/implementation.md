# Factory reset implementation reference

## Official documentation

- [Factory reset](https://docs-aibuds.github.io/docs/core/basic-features/factory-reset)
- [AIBuds SDK API Reference](https://docs-aibuds.github.io/api-reference/aibuds-sdk)

## Public API

```swift
public protocol DeviceCommonAPI: DeviceAPI {
    func factoryReset(_ completion: AIBudsCompletionHandler?)
}
```

`AIBudsCompletionHandler` reports a `Bool` success value and a nullable `NSError`.

## Swift pattern

Adapt this to the application's existing state and presentation architecture:

```swift
guard let commonDevice = device as? DeviceCommonAPI else {
    // Disable the action or present an unsupported message.
    return
}

commonDevice.factoryReset { success, error in
    DispatchQueue.main.async {
        if success {
            // Present success and continue observing SDK device state.
        } else {
            let message = error?.localizedDescription ?? "Factory reset failed"
            // Present the failure through the app's existing error UI.
        }
    }
}
```

## Objective-C pattern

```objective-c
id<AIBudsDeviceCommonAPI> commonDevice = (id<AIBudsDeviceCommonAPI>)self.device;
if (![commonDevice conformsToProtocol:@protocol(AIBudsDeviceCommonAPI)]) {
    return;
}

[commonDevice factoryResetWithCompletion:^(BOOL success, NSError * _Nullable error) {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString *message = success
            ? @"Factory reset successful"
            : (error.localizedDescription ?: @"Factory reset failed");
        // Present the result through the app's existing UI.
    });
}];
```

## Safety and lifecycle

- Ask for explicit user confirmation immediately before the call.
- Disable repeated submission until the callback arrives or the application cancels its in-flight UI state.
- The public method does not document its callback queue, so dispatch UI work to the main queue.
- Treat reset scope, restart timing, disconnection, and re-pairing as product-specific unless the developer provides an authoritative product contract.
- Continue using the application's existing SDK callbacks as the source of truth for connection state.

## Verification matrix

| Case | Expected behavior |
|---|---|
| User cancels | Do not call the SDK. |
| Protocol unsupported | Disable or reject the action without a force cast. |
| `success == true` | Show success on the main queue and keep observing device state. |
| `success == false`, error present | Show the localized error through existing UI. |
| `success == false`, error nil | Show a stable fallback message. |
| Repeated tap | Submit at most one in-flight request. |
