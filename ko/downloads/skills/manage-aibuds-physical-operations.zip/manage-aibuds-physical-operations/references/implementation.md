# Manage AIBuds Physical Operations: public integration reference

## Scope and public contracts

Use this reference to inspect physical-operation mappings and assign supported functions. Confirm exact declarations in the installed SDK version before editing the consumer app.

- `DevicePhysicalOperationsAPI`
- `physicalOperationsMapping`
- `assignFunction(_:forPhysicalOperation:completion:)`

## Official documentation

- [docs/core/physical-operations/view-operation-mapping ](https://docs-aibuds.github.io/docs/core/physical-operations/view-operation-mapping)
- [docs/core/physical-operations/assign-functions ](https://docs-aibuds.github.io/docs/core/physical-operations/assign-functions)
- [docs/core/physical-operations/operation-and-function-reference ](https://docs-aibuds.github.io/docs/core/physical-operations/operation-and-function-reference)
- [AIBuds SDK API Reference](https://docs-aibuds.github.io/api-reference/aibuds-sdk)
- [Common troubleshooting](https://docs-aibuds.github.io/docs/troubleshooting/common-issues)


## Portable workflow

1. Initialize only the documented module needed for this feature.
2. Wait for the public ready callback and cast the selected `DeviceConvertible` to `DevicePhysicalOperationsAPI` safely.
3. Validate user input and public capability/range information before calling the SDK.
4. Serialize mutually exclusive operations and keep callback/session owners alive for as long as the public contract requires.
5. Treat callback success and error as the operation result. Move UI work to the main queue and use public connection callbacks as the source of truth.
6. On cancellation, view exit, background transition, or disconnect, stop only through a documented stop/cancel API and clear application-owned state.

## Swift pattern

Adapt names such as `device`, handlers, models, and UI functions to the consumer app. Do not copy repository-specific helpers.

```swift
guard device.isConnectedAndReady else { return }
// guard let featureDevice = device as? DevicePhysicalOperationsAPI else { return }

let mapping = operationDevice.physicalOperationsMapping
operationDevice.assignFunction(function, forPhysicalOperation: operation) { success, error in
    finish(success, error)
}
```

## Objective-C pattern

Use the Objective-C names exposed by the installed generated interface; availability and nullability remain authoritative.

```objective-c
if (!device.isConnectedAndReady) { return; }
// Check conformsToProtocol: before casting to the public protocol.

NSArray *mapping = operationDevice.physicalOperationsMapping;
[operationDevice assignFunction:function forPhysicalOperation:operation completion:^(BOOL success, NSError *error) {
    finish(success, error);
}];
```

## Error and lifecycle rules

- Do not force-cast optional capabilities or assume a callback queue.
- Prevent repeated submissions while an operation is in flight.
- Dispatch presentation/state mutations to the main queue.
- Show `localizedDescription` when a public error exists and a stable fallback otherwise.
- Do not guess device state after a command; reconcile it through public properties and callbacks.
- Keep credentials, private endpoints, and app-owned AI/network implementations outside SDK calls.

## Verification matrix

| Case | Expected check |
|---|---|
| Device or service unavailable | Reject cleanly without calling an unsupported API. |
| Success | Update UI on the main queue and refresh public state when relevant. |
| Failure with error | Present the public localized error without internal interpretation. |
| Failure without error | Present a stable application-owned fallback message. |
| Repeated action | Keep at most one incompatible request/session in flight. |
| Disconnect or lifecycle exit | Cancel/stop through public API when available and clear app state. |
| Only documented operation/function pairs are offered. | Confirm the app behaves deterministically and reports public errors safely. |
| The mapping is refreshed after a successful assignment. | Confirm the app behaves deterministically and reports public errors safely. |
| Unsupported combinations remain unchanged. | Confirm the app behaves deterministically and reports public errors safely. |

## Information boundary

Explain what the public call accepts, what its public callback reports, and how the app should react. Do not describe transport details, command encoding, SDK source structure, private dependencies, or internal execution paths.
