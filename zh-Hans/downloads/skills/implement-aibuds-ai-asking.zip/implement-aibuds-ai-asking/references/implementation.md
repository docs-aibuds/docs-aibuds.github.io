# Implement AIBuds AI Asking: public integration reference

## Scope and public contracts

Use this reference to send standalone text questions and correlate streamed answers without creating an AI chat session. Confirm exact declarations in the installed SDK version before editing the consumer app.

- `AIBudsAISDK`
- `AIAskingConfig`
- `send(question:config:onStartAnswering:onAnswer:onFinishAnswering:onError:)`

## Official documentation

- [docs/ai/ai-asking ](https://docs-aibuds.github.io/docs/ai/ai-asking)
- [docs/advanced-topics/bring-your-own-ai ](https://docs-aibuds.github.io/docs/advanced-topics/bring-your-own-ai)
- [AIBuds SDK API Reference](https://docs-aibuds.github.io/api-reference/aibuds-sdk)
- [Common troubleshooting](https://docs-aibuds.github.io/docs/troubleshooting/common-issues)

## AI Asking versus AI Chat

AI Asking submits a standalone text question and returns an optional question identifier. Its callbacks may provide the identifier again and stream delta or accumulated answer text.

It does not create an `AIChatSessionConvertible`, and it must not use a chat session's `sendText(_:)` method. Route multi-turn conversational session requirements to the dedicated AI Chat skill.


## Portable workflow

1. Initialize the documented AI service and select/configure the intended provider through public APIs.
2. Validate the question before submission; do not create an AI Chat session.
3. Store the optional identifier returned by `send(question:...)` and accept that `onStartAnswering` may also supply it.
4. Correlate `onAnswer`, `onFinishAnswering`, and `onError` by question identifier. Distinguish delta text, accumulated text, and `isFinal` without concatenating both representations blindly.
5. Treat finish and error as terminal outcomes. If the screen or request owner goes away, ignore late callbacks by identifier because this public API exposes no cancellation method.
6. Dispatch UI work to the main queue because the provider determines callback queues.

## Swift pattern

Adapt names such as `device`, handlers, models, and UI functions to the consumer app. Do not copy repository-specific helpers.

```swift
// Initialize and configure the documented SDK-level service before use.


let questionID = AIBudsAISDK.send(
    question: question,
    config: config,
    onStartAnswering: { id in markStarted(id) },
    onAnswer: { id, delta, full, isFinal in renderAnswer(id, delta, full, isFinal) },
    onFinishAnswering: { id in markFinished(id) },
    onError: { id, error in markFailed(id, error) }
)
// Correlate every callback with questionID or its callback identifier.
```

## Objective-C pattern

Use the Objective-C names exposed by the installed generated interface; availability and nullability remain authoritative.

```objective-c
// Initialize and configure the documented SDK-level service before use.


NSString *questionID = [AIBudsAISDK sendQuestion:question
    config:config
    onStartAnswering:^(NSString *identifier) { markStarted(identifier); }
    onAnswer:^(NSString *identifier, NSString *delta, NSString *full, BOOL isFinal) { renderAnswer(identifier, delta, full, isFinal); }
    onFinishAnswering:^(NSString *identifier) { markFinished(identifier); }
    onError:^(NSString *identifier, NSError *error) { markFailed(identifier, error); }];
// Correlate every callback with questionID or its callback identifier.
```

## Error and lifecycle rules

- Do not create, retain, start, or stop an AI Chat session for this feature.
- Reject an empty question before submission and handle a `nil` synchronous question identifier.
- Correlate every callback by identifier so concurrent or stale requests cannot update the wrong UI.
- Render either accumulated text or deltas according to the callback values; do not duplicate content.
- Dispatch presentation/state mutations to the main queue.
- Keep credentials, private endpoints, and app-owned AI/network implementations outside SDK calls.

## Verification matrix

| Case | Expected check |
|---|---|
| Device or service unavailable | Reject cleanly without calling an unsupported API. |
| Success | Update UI on the main queue and refresh public state when relevant. |
| Failure with error | Present the public localized error without internal interpretation. |
| Failure without error | Present a stable application-owned fallback message. |
| Repeated action | Keep at most one incompatible request/session in flight. |
| Disconnect or lifecycle exit | Cancel/stop through public API when available and clear app state. |
| No AIChatSessionConvertible is created or used for AI Asking. | Confirm the app behaves deterministically and reports public errors safely. |
| Empty input is rejected and the optional returned question identifier is handled. | Confirm the app behaves deterministically and reports public errors safely. |
| Only callbacks matching the active question update its answer. | Confirm the app behaves deterministically and reports public errors safely. |

## Information boundary

Explain what the public call accepts, what its public callback reports, and how the app should react. Do not describe transport details, command encoding, SDK source structure, private dependencies, or internal execution paths.
