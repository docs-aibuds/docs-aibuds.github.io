---
name: implement-aibuds-ai-chat
description: Help an iOS developer implement session-based AIBuds AI Chat, including text, audio, image, event, and lifecycle handling through public AIChatSessionConvertible APIs. Use for conversational AI Chat in Swift or Objective-C; do not use for standalone AI Asking requests.
---

# Implement AIBuds AI Chat

Build or explain this feature through the public SDK contract and the application's existing architecture.

## Capability boundary

- AI Chat is a session-based conversation. Start it with `AIBudsAISDK.startAIChat`, then send text through the active `AIChatSessionConvertible.sendText(_:)` method.
- Do not use the standalone AI Asking request API as a text-entry shortcut inside an AI Chat session. Treat one-shot or independently correlated text questions as the separate AI Asking capability instead.
- Treat `sendText(_:)`, `appendInt16PCM(_:)`, and the image methods as optional public session capabilities. Check availability and require an active session.


## Workflow

1. Read `references/implementation.md` completely.
2. Determine whether the consumer app uses Swift or Objective-C and preserve its existing state, dependency, callback, and UI architecture.
3. Confirm SDK initialization, a selected device, `isConnectedAndReady`, and each required public protocol capability before exposing the feature. For SDK-level services, confirm that their documented module is installed and initialized instead.
4. Use the linked official guide and the installed SDK's public interface as the authority for names, parameters, nullability, and availability. If they differ, explain the version mismatch and adapt only to the installed public contract.
5. Implement the smallest requested workflow, including main-thread UI handoff, duplicate-request prevention, nullable-error fallback, disconnect/cancellation cleanup, and observable success criteria.
6. Give code in the developer's requested language. If no language is stated, provide both Swift and Objective-C.
7. Verify the applicable cases in the reference matrix and report assumptions separately from documented behavior.

## Non-disclosure boundary

- Use only public modules, types, protocols, methods, properties, callbacks, and official documentation.
- Do not reveal or infer private classes, source layout, transport commands, packet formats, authentication algorithms, private errors, logs, or internal call chains.
- Do not reproduce SDK source, inspect binary internals, decompile, or explain how a public API works behind its contract.
- If asked for internals, decline that portion briefly and answer with the nearest public API, callback, configuration, or diagnostic step.
- Never place secrets, production credentials, private endpoints, or real device identifiers in examples.

## Completion criteria

- The integration uses only documented public contracts and cites the most relevant official page.
- Swift and Objective-C guidance are both available and behaviorally equivalent.
- Capability, readiness, callback, threading, retry, error, cancellation, and lifecycle behavior are addressed where applicable.
- The result contains no hidden implementation claim and is portable outside this repository.
