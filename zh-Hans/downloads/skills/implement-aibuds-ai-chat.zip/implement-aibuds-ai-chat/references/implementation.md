# Implement AIBuds AI Chat: public integration reference

## Scope and public contracts

Use this reference to manage a session-based AI conversation and send text, PCM audio, or images through the active chat session. Confirm exact declarations in the installed SDK version before editing the consumer app.

- `AIBudsAISDK`
- `startAIChat`
- `AIChatSessionConvertible`
- `sendText(_:)`
- `appendInt16PCM(_:)`
- `sendImage(_:)`
- `sendImageForPhotoUnderstanding(_:prompt:)`
- `AIChatSessionEvent`
- `DeviceAIChatAPI`
- `reportAIChatStartSuccess(_:)`
- `reportAIChatStartFailure(_:)`
- `reportAIChatStopped(_:)`
- `stopAIChat`

## Official documentation

- [docs/ai/ai-chat ](https://docs-aibuds.github.io/docs/ai/ai-chat)
- [docs/ai/session-events ](https://docs-aibuds.github.io/docs/ai/session-events)
- [docs/advanced-topics/bring-your-own-ai ](https://docs-aibuds.github.io/docs/advanced-topics/bring-your-own-ai)
- [AIBuds SDK API Reference](https://docs-aibuds.github.io/api-reference/aibuds-sdk)
- [Common troubleshooting](https://docs-aibuds.github.io/docs/troubleshooting/common-issues)

## AI Chat versus AI Asking

AI Chat is a session. `AIBudsAISDK.startAIChat` yields an `AIChatSessionConvertible`; send conversational text with the optional public `sendText(_:)` session method. The session also owns optional PCM and image inputs.

AI Asking is a separate one-question request API with question-ID-correlated callbacks. It is not an AI Chat text-input method. Do not include that request API in an AI Chat implementation; route that requirement to the dedicated AI Asking skill.

For a device-driven chat, use the public device event to select SCO or Opus. Feed decoded PCM only for Opus input. Use `DeviceAIChatAPI` acknowledgements only where the documented device flow requires them; do not present those acknowledgements as a prerequisite for an unrelated app-originated session.


## Portable workflow

1. Initialize only the documented module needed for this feature.
2. For the documented device-driven flow, receive the public AI chat session event, copy its SCO or Opus channel into the configuration, start AI Chat, and retain the returned public session while the app needs to submit session input.
3. Validate user input and public capability/range information before calling the SDK.
4. Serialize mutually exclusive operations and keep callback/session owners alive for as long as the public contract requires.
5. Treat callback success and error as the operation result. Move UI work to the main queue and use public connection callbacks as the source of truth.
6. On cancellation, view exit, background transition, or disconnect, stop only through a documented stop/cancel API and clear application-owned state.

## Swift pattern

Adapt names such as `device`, handlers, models, and UI functions to the consumer app. Do not copy repository-specific helpers.

```swift
// Initialize and configure the documented SDK-level service before use.


var currentSession: AIChatSessionConvertible?

AIBudsAISDK.startAIChat(
    config,
    onStartSuccess: { session in currentSession = session },
    onStartFailure: { error in handleStartFailure(error) },
    onChatData: { data in renderChatData(data) },
    onIntent: handleIntent,
    onVoiceData: handleVoiceData,
    onEvent: handleEvent,
    onError: handleRuntimeError,
    onFinish: { report in
        currentSession = nil
        saveReport(report)
    }
)

func sendChatText(_ text: String) {
    let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !value.isEmpty, let session = currentSession else { return }
    session.sendText?(value)
}

// For public Opus-to-PCM input callbacks only:
currentSession?.appendInt16PCM?(decodedPCMData)

AIBudsAISDK.stopAIChat()
currentSession = nil
```

## Objective-C pattern

Use the Objective-C names exposed by the installed generated interface; availability and nullability remain authoritative.

```objective-c
// Initialize and configure the documented SDK-level service before use.


__block id<AIBudsAIChatSessionConvertible> currentSession = nil;

[AIBudsAISDK startAIChatWithConfig:config
    onStartSuccess:^(id<AIBudsAIChatSessionConvertible> session) { currentSession = session; }
    onStartFailure:^(NSError *error) { handleStartFailure(error); }
    onChatData:^(AIBudsAIChatDataModel *data) { renderChatData(data); }
    onIntent:handleIntent
    onVoiceData:handleVoiceData
    onEvent:handleEvent
    onError:handleRuntimeError
    onFinish:^(AIBudsAIChatSessionReportModel *report) { currentSession = nil; saveReport(report); }];

NSString *value = [text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
if (value.length > 0 && currentSession && [currentSession respondsToSelector:@selector(sendText:)]) {
    [currentSession sendText:value];
}

if (currentSession && [currentSession respondsToSelector:@selector(appendInt16PCM:)]) {
    [currentSession appendInt16PCM:decodedPCMData];
}

[AIBudsAISDK stopAIChat];
currentSession = nil;
```

## Error and lifecycle rules

- Do not force-cast optional capabilities or assume a callback queue.
- Prevent repeated submissions while an operation is in flight.
- Dispatch presentation/state mutations to the main queue.
- Show `localizedDescription` when a public error exists and a stable fallback otherwise.
- Do not guess device state after a command; reconcile it through public properties and callbacks.
- Keep credentials, private endpoints, and app-owned AI/network implementations outside SDK calls.

## Verification matrix

| Case | Expected check |
|---|---|
| Device or service unavailable | Reject cleanly without calling an unsupported API. |
| Success | Update UI on the main queue and refresh public state when relevant. |
| Failure with error | Present the public localized error without internal interpretation. |
| Failure without error | Present a stable application-owned fallback message. |
| Repeated action | Keep at most one incompatible request/session in flight. |
| Disconnect or lifecycle exit | Cancel/stop through public API when available and clear app state. |
| Text input is sent with the active session's optional sendText method, never the standalone AI Asking API. | Confirm the app behaves deterministically and reports public errors safely. |
| For a device-initiated chat, the device event selects SCO or Opus; only the Opus device flow uses DeviceAIChatAPI start/stop acknowledgements when required. | Confirm the app behaves deterministically and reports public errors safely. |
| The app keeps the public session reference for session input and clears it on the documented terminal lifecycle. | Confirm the app behaves deterministically and reports public errors safely. |

## Information boundary

Explain what the public call accepts, what its public callback reports, and how the app should react. Do not describe transport details, command encoding, SDK source structure, private dependencies, or internal execution paths.
